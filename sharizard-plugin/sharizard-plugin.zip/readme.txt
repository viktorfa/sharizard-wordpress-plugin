=== Sharizard Wordpress ===

Contributors: vikfand
Tags: open graph, social media, preview, image, share
Requires at least: 5.2
Tested up to: 5.9
Requires PHP: 7.1.0
Stable tag: 1.0.0
License: GPL version 3 or any later version
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Automatically get social media preview images for all your pages. No setup required. Increase engagement by showing your title and excerpt as a big image when your links are shared on social media. 

== Description ==

Simple Social Media Preview will automatically generate an image for your pages when shared on social media. It will add meta tags for og:image and twitter:image in the correct formats.

The images will contain the title and excerpt of your posts.

Managing social media preview images can be a hassle and require a lot of nitpicking. Other plugins require you to manually generate or configure images, but Simple Social Media Preview automatically generates an image for all your posts.

The images are generated on our servers, so it does not use any storage on your installation.

This is the long description. No limit, and you can use Markdown (as well as in the following sections).

== Installation ==

Install and activate the plugin. Configure the text color and background color in the settings.

== Frequently Asked Questions ==

== Changelog ==

= 1.0.0 =
* February 26, 2022

== Upgrade Notice ==

== Screenshots ==
